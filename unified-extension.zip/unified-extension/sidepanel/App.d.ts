/**
 * Main App Component for the Sidebar Panel
 */
export declare function App(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=App.d.ts.map