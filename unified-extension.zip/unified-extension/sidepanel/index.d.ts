/**
 * Sidebar Panel - Entry point for the chat UI
 */
import './styles/main.css';
//# sourceMappingURL=index.d.ts.map