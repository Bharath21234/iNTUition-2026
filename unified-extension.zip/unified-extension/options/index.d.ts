/**
 * Options Page - Entry point for settings UI
 */
import './styles.css';
//# sourceMappingURL=index.d.ts.map