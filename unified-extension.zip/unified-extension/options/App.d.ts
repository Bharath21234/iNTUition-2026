/**
 * Options Page App Component
 */
export declare function App(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=App.d.ts.map