/**
 * Content Script - Injected into web pages
 * Handles DOM parsing, action execution, and UI modifications
 */
export {};
//# sourceMappingURL=index.d.ts.map